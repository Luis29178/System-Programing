#pragma once
#include "BaseAccount.h"
class SavingAccount : public BaseAccount
{
public:
	void Withdraw(float ammount);


};

