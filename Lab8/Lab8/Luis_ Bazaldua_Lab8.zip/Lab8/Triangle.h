#pragma once
class Triangle
{
private:
	int base;
	int Hight;


public:
	int getArea();


};

