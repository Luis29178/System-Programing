#include "Triangle.h"

int Triangle::getArea()
{
    int area = (base * Hight) / 2;
    return area;
}


