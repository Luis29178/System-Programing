#pragma once
#include <string>
#include <iostream>


namespace StringHelpers {
	std::string FormatMoneyText(long long money);
	std::string IntToString(int num);
}

